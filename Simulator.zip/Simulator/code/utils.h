//---------------------------------------------------
// Utils
// By: Breno Cunha Queiroz and Maria Eduarda Kawakami
// Date: 12/06/20
//---------------------------------------------------
#ifndef _H_UTILS
#define _H_UTILS


// Funcao que separa somente o pedaco de interesse do IR;
int pega_pedaco(int ir, int a, int b);

#endif
