Manual:

- Salve seus arquivos na pasta "Simulador".
- Tenha certeza que o "charmap.mif" tamb�m est� na pasta "Simulador".
- Para programar, utilize o "sublime_text.exe" dentro da pasta "Sublime Text 3".
- Com o Sublime Text aberto, pressione F7 para Montar e Simular o c�digo.

F.A.Q:

- Meu F7 n�o compila!
	V� em Tools > Build System , e verifique se a op��o "Assembly ICMC" est� selecionada.

Outros erros, d�vidas ou sugest�es sobre o Sublime Text, entre em contato: carlosasj@hotmail.com.br